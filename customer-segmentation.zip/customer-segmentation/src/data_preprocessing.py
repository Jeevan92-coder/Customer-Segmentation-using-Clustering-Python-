import pandas as pd
import numpy as np
from datetime import datetime

def load_data(filepath):
    """
    Load the retail dataset
    """
    df = pd.read_csv(filepath, encoding='ISO-8859-1')
    print(f"Dataset Shape: {df.shape}")
    return df

def clean_data(df):
    """
    Clean and prepare data for analysis
    """
    # 1. Remove missing CustomerIDs
    df = df[df['CustomerID'].notna()]
    
    # 2. Remove cancelled orders (InvoiceNo starting with 'C')
    df = df[~df['InvoiceNo'].astype(str).str.startswith('C')]
    
    # 3. Remove negative quantities and prices
    df = df[(df['Quantity'] > 0) & (df['UnitPrice'] > 0)]
    
    # 4. Convert InvoiceDate to datetime
    df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'])
    
    # 5. Create TotalPrice column
    df['TotalPrice'] = df['Quantity'] * df['UnitPrice']
    
    print(f"Cleaned Dataset Shape: {df.shape}")
    return df

def create_rfm_features(df):
    """
    Create RFM (Recency, Frequency, Monetary) features
    """
    # Reference date (last date + 1 day)
    reference_date = df['InvoiceDate'].max() + pd.Timedelta(days=1)
    
    # Group by CustomerID
    rfm = df.groupby('CustomerID').agg({
        'InvoiceDate': lambda x: (reference_date - x.max()).days,  # Recency
        'InvoiceNo': 'nunique',                                     # Frequency
        'TotalPrice': 'sum'                                         # Monetary
    })
    
    # Rename columns
    rfm.columns = ['Recency', 'Frequency', 'Monetary']
    
    # Additional features
    rfm['AvgOrderValue'] = df.groupby('CustomerID')['TotalPrice'].mean()
    rfm['TotalQuantity'] = df.groupby('CustomerID')['Quantity'].sum()
    
    return rfm