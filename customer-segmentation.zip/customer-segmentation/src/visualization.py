import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA

def plot_cluster_distribution(df, cluster_column='Cluster'):
    """
    Show cluster sizes
    """
    plt.figure(figsize=(10, 6))
    cluster_counts = df[cluster_column].value_counts().sort_index()
    
    colors = sns.color_palette('husl', len(cluster_counts))
    bars = plt.bar(cluster_counts.index, cluster_counts.values, color=colors, edgecolor='black')
    
    # Add value labels
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2., height,
                f'{int(height)}',
                ha='center', va='bottom', fontsize=11, fontweight='bold')
    
    plt.xlabel('Cluster', fontsize=13)
    plt.ylabel('Number of Customers', fontsize=13)
    plt.title('Customer Distribution Across Clusters', fontsize=15, fontweight='bold')
    plt.xticks(cluster_counts.index)
    plt.grid(axis='y', alpha=0.3)
    plt.savefig('reports/figures/cluster_distribution.png', dpi=300, bbox_inches='tight')
    plt.show()

def plot_rfm_heatmap(df, cluster_column='Cluster'):
    """
    Heatmap of RFM values by cluster
    """
    cluster_profile = df.groupby(cluster_column)[['Recency', 'Frequency', 'Monetary']].mean()
    
    plt.figure(figsize=(10, 6))
    sns.heatmap(cluster_profile.T, annot=True, fmt='.2f', cmap='YlOrRd', 
                cbar_kws={'label': 'Average Value'}, linewidths=1, linecolor='black')
    plt.xlabel('Cluster', fontsize=13)
    plt.ylabel('RFM Metrics', fontsize=13)
    plt.title('Cluster Profiling - RFM Heatmap', fontsize=15, fontweight='bold')
    plt.savefig('reports/figures/rfm_heatmap.png', dpi=300, bbox_inches='tight')
    plt.show()

def plot_3d_clusters(scaled_data, clusters):
    """
    3D visualization using PCA
    """
    # Reduce to 3 dimensions
    pca = PCA(n_components=3)
    pca_data = pca.fit_transform(scaled_data)
    
    fig = plt.figure(figsize=(12, 8))
    ax = fig.add_subplot(111, projection='3d')
    
    scatter = ax.scatter(pca_data[:, 0], pca_data[:, 1], pca_data[:, 2], 
                        c=clusters, cmap='viridis', s=50, alpha=0.6, edgecolors='k')
    
    ax.set_xlabel('PC1', fontsize=11)
    ax.set_ylabel('PC2', fontsize=11)
    ax.set_zlabel('PC3', fontsize=11)
    ax.set_title('3D Cluster Visualization (PCA)', fontsize=14, fontweight='bold')
    
    plt.colorbar(scatter, label='Cluster')
    plt.savefig('reports/figures/3d_clusters.png', dpi=300, bbox_inches='tight')
    plt.show()

def plot_boxplots(df, cluster_column='Cluster'):
    """
    Boxplots for each RFM metric
    """
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    metrics = ['Recency', 'Frequency', 'Monetary']
    
    for i, metric in enumerate(metrics):
        sns.boxplot(data=df, x=cluster_column, y=metric, palette='Set2', ax=axes[i])
        axes[i].set_title(f'{metric} by Cluster', fontsize=13, fontweight='bold')
        axes[i].set_xlabel('Cluster', fontsize=11)
        axes[i].set_ylabel(metric, fontsize=11)
        axes[i].grid(axis='y', alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('reports/figures/rfm_boxplots.png', dpi=300, bbox_inches='tight')
    plt.show()